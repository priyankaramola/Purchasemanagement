import React from "react";

const Supplies = () => {
  return (
    <div>
      <h2 className="text-xl font-bold mb-2">Supplies Information</h2>
      <p>This is the content for the Supplies tab.</p>
    </div>
  );
};

export default Supplies;
